<?php

$db=array('DB_TYPE' => 'mysql','DB_HOST' => '127.0.0.1','DB_NAME' => 'yuanlu_fund1','DB_USER' => 'root','DB_PWD' => '','DB_PORT' => '3306','DB_PREFIX' => '',);
return $db;
