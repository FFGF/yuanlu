<?php

$date_cache_time = array(
  'customer_model'    => array('min_time' => 30, 'max_time' => 3600),
  'examine_model'     => array('min_time' => 30, 'max_time' => 3600),
  'finance_model'     => array('min_time' => 30, 'max_time' => 3600),
  'message_model'     => array('min_time' => 30, 'max_time' => 3600),
  'order_model'       => array('min_time' => 30, 'max_time' => 3600),
  'withdrawals_model' => array('min_time' => 30, 'max_time' => 3600)
);
