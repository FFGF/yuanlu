# yuanlu
将yuanlu_fund1.sql导入到MySQL数据库
修改代码中的数据库连接配置，即可运行代码
